from flask import Flask, request, jsonify, send_from_directory, render_template
from flask_cors import CORS
import pickle
import numpy as np
import os
from sklearn.preprocessing import StandardScaler

# Initialize Flask app with static folder configuration
app = Flask(__name__, static_folder='static')
CORS(app, resources={r"/api/*": {"origins": "*"}})  # Allow all origins for API endpoints

# Global variables for model and scaler
model = None
scaler = None

# Load the model and scaler
def load_model():
    global model, scaler
    model_path = os.path.join(os.path.dirname(__file__), 'model', 'breast_cancer_model.pkl')
    scaler_path = os.path.join(os.path.dirname(__file__), 'model', 'scaler.pkl')
    
    try:
        with open(model_path, 'rb') as f:
            model = pickle.load(f)
        
        with open(scaler_path, 'rb') as f:
            scaler = pickle.load(f)
        print("Model and scaler loaded successfully!")
    except Exception as e:
        print(f"Error loading model or scaler: {e}")

# Load model when app starts
load_model()

# Route to serve the main page
@app.route('/')
def index():
    return send_from_directory('static', 'index.html')

@app.route('/api/predict', methods=['POST'])
def predict():
    data = request.json
    
    # Extract features from the request
    features = [
        float(data['radius_mean']),
        float(data['texture_mean']),
        float(data['perimeter_mean']),
        float(data['area_mean']),
        float(data['smoothness_mean']),
        float(data['compactness_mean']),
        float(data['concavity_mean']),
        float(data['concave_points_mean']),
        float(data['symmetry_mean']),
        float(data['fractal_dimension_mean'])
    ]
    
    # Reshape and scale the features
    features_array = np.array(features).reshape(1, -1)
    scaled_features = scaler.transform(features_array)
    
    # Make prediction
    prediction = model.predict(scaled_features)
    probability = model.predict_proba(scaled_features)
    
    result = {
        'prediction': int(prediction[0]),
        'prediction_label': 'Cancerous' if prediction[0] == 1 else 'Non-Cancerous',
        'probability': {
            'benign': float(probability[0][0]),
            'malignant': float(probability[0][1])
        }
    }
    
    return jsonify(result)

@app.route('/api/health', methods=['GET'])
def health_check():
    return jsonify({'status': 'ok'})

if __name__ == '__main__':
    app.run(debug=True, port=5000)