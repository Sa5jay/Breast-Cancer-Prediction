from graphviz import Digraph
dot = Digraph()
dot.edge("Input Data", "Preprocessing")
dot.edge("Preprocessing", "Model Training")
dot.edge("Model Training", "Prediction")
dot.edge("Prediction", "Output")
dot.render('flow_diagram', format='png')
print("Diagram generated as 'flow_diagram.png'")
